﻿
Partial Class Customers_customersDetailed
    Inherits System.Web.UI.Page

End Class
