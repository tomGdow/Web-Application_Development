﻿Imports Microsoft.VisualBasic

Namespace DataSet2TableAdapters
    Public Class SuppliersTableAdapter

        Function GetProducts() As Object
            Throw New NotImplementedException
        End Function

    End Class
End Namespace