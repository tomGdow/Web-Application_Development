﻿
Partial Class Stock_formattedXML
    Inherits System.Web.UI.Page

End Class
