﻿
Partial Class Stock_stockEntryMaster
    Inherits System.Web.UI.Page

    Protected Sub Stock_levelTextBox_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs)

    End Sub

    Protected Sub DescriptionTextBox_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs)

    End Sub

    Protected Sub StockIDTextBox_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs)

    End Sub
End Class
