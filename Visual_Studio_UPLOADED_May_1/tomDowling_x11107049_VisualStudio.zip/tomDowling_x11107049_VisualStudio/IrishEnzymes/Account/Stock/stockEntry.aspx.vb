﻿
Partial Class Stock_stockEntry
    Inherits System.Web.UI.Page

End Class
