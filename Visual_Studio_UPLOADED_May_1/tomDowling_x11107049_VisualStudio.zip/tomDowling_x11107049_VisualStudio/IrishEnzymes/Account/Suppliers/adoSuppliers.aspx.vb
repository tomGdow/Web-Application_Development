﻿
Partial Class Suppliers_adoSuppliers
    Inherits System.Web.UI.Page

End Class
