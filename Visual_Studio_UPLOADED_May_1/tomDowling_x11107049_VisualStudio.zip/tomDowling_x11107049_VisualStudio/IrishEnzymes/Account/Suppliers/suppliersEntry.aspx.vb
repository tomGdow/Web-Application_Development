﻿
Partial Class Suppliers_suppliersEntry
    Inherits System.Web.UI.Page

End Class
