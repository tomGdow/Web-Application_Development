﻿
Partial Class Suppliers_suppliersEntryMaster
    Inherits System.Web.UI.Page

    Protected Sub CountryTextBox_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs)

    End Sub

    Protected Sub SupplierNameTextBox_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs)

    End Sub
End Class
