﻿
Partial Class Customers_masterDetails
    Inherits System.Web.UI.Page

End Class
